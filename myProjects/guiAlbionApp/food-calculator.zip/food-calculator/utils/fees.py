class Fees:
    MARKET_FEE = 0.045
